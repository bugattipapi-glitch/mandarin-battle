# NEO TOKYO: SECTOR 67

A retro arcade horizontal shooter that teaches Mandarin. Defend Neo Tokyo's Sector 67
from the alien invasion — answer Mandarin character questions to earn weapon upgrades,
and decode the priority transmission before each boss to arm the HYPER BEAM.

## Play it

The whole game is one file: `index.html`. Open it in any modern browser — desktop,
iPad, or phone. No build step, no dependencies.

- **PC:** Arrow keys or WASD to fly. Auto-fire is always on. P / Esc to pause.
- **Touch:** Drag anywhere on the screen to fly.

## Features

- 5 visually distinct sectors: Shinjuku's kanji-neon canyons, a sunset harbor with cranes and a patrolling tanker, a daytime Fuji-view expressway with drifting clouds and road signs, a foundry district with smokestacks and rising embers, and a midnight Mt. Fuji ascent with torii gates, lanterns, and shooting stars
- Mandarin quiz bank (~90 characters/words) tiered for US Chinese-as-a-second-language learners up to 2nd grade
- 11 upgrade types: 5 weapon systems (each 4 levels), shields, armor, speed, miniaturize, drones, fire rate
- 5 unique bosses with animated attack features — spinning gatlings, a hangar maw, sweeping energy blades, tracking turrets, and writhing tentacles
- Real arcade soundtrack: nine CC0 chiptune tracks by Juhani Junkala (title, overworld, one per sector, boss, victory), streamed from the Internet Archive with an automatic fallback to a built-in synth engine if streaming is unavailable — ♪ HIGH / LOW / MUTE button included
- Authentic 480×270 pixel-art rendering pipeline: banded dithered skies, streak clouds, painterly terrain, and chunky upscaled sprites
- Cinematic story intro, a squadron-flypast title screen, and a Street Fighter-style pilot select: Strike Leader Jackson, General Arthur, Demolition Specialist Paulo, or Gunnery Sgt. Ollie — each pilot flies their own ship livery
- 13 upgrade types including auto-lobbing BLAST BOMBS (area damage) and a DEFLECTOR PLATE that bounces 10 enemy shots back before a 20-second recharge
- Boss fights scale to your firepower: roughly 15-30 seconds with your regular loadout, 5-10 with the boss-code super weapon, which alternates between the HYPER BEAM and the DRAGON FLAME each sector
- Enemy armor scales with your loadout from Sector 2 onward, and in Danger Zone every 5th alien that escapes past you strips one of your upgrades — but downgrades can never take your starting vulcan cannon
- Arcade-style TAP TO START splash screen (this is also what lets browsers play the soundtrack from the story intro onward)
- Every boss machine has a named pilot: Captain Skarn, Mother Velga, Kiro Twinblade, Warlord Tetsuo, and Emperor Zahhak
- Radio-chatter voice comms ("Good luck." / "Warning!" / "Hyper beam armed." / "Great success!" / "Critical damage!"), capped at a few lines per level
- Two modes: NORMAL MISSION, and DANGER ZONE — escaped aliens cost points, and every wrong answer downgrades or removes one of your upgrades
- A flashing PRIORITY ALERT klaxon announces the boss-code question before every boss
- Question decks shuffle per playthrough — no repeated characters until a tier's pool is exhausted
- Overworld sector map with a mini ship that flies between unlocked levels
- Cumulative score, best-score and level-unlock saving (localStorage when hosted)

## Host it on GitHub Pages

1. Create a new **public** repository on GitHub.
2. Upload `index.html` (and this README) via **Add file → Upload files**.
3. Go to **Settings → Pages**, set Source to **Deploy from a branch**, branch `main`, folder `/ (root)`.
4. Your game is live at `https://YOUR_USERNAME.github.io/YOUR_REPO/` in a minute or two.

## Music credits

All music is by **Juhani Junkala** (SubspaceAudio), released **CC0 / public domain**:
- "5 Chiptunes (Action)" — https://opengameart.org/content/5-chiptunes-action
- "4 Chiptunes (Adventure)" — https://opengameart.org/content/4-chiptunes-adventure

Tracks stream from the Internet Archive. To self-host instead (recommended for reliability),
download the MP3s, put them in your repo, and update the `TRACKS` map near the top of the
music section in `index.html` to point at your local paths. If streaming fails or is blocked,
the game automatically falls back to its built-in synth soundtrack.
